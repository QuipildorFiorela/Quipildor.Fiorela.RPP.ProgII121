
package recuparcial1fiorelaquipildor;

public class Exploracion extends NaveEspacial implements Explorable {
    private TipoMision mision;

    public Exploracion(TipoMision mision, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.mision = mision;
    }

    @Override
    public void explorar() {
        System.out.println("Explorando la nave espacial '" + nombre + "' tipo Exploracion.");
    }

    @Override
    public String toString() {
        return "Exploracion{" + "mision=" + mision + ", nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + '}';
    }
    
}
