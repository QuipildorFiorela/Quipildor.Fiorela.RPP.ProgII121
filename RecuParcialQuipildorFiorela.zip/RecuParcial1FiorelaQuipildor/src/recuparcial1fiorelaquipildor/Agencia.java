
package recuparcial1fiorelaquipildor;

import java.util.List;

public class Agencia {
    
    private List<NaveEspacial> navesEspaciales;

    public Agencia(List<NaveEspacial> navesEspaciales) {
        this.navesEspaciales = navesEspaciales;
    }
    
    public void agregarNave(NaveEspacial nave) throws NaveRepetidaException {
        if (navesEspaciales.contains(nave)) { 
            throw new NaveRepetidaException("La nave '" + nave.nombre +  "' con capacidad de tripulacion '" + nave.capacidadTripulacion + "' ya existe en la agencia!!!"); //Si en la lista de naves ya existe una nave con el mismo nombre y capacidad de tripulacion que la que se intenta agregar, lanza la excepcion.
        } else {
            navesEspaciales.add(nave);
        }
    } 
    
    public void mostrarNaves() {
        for (NaveEspacial n : navesEspaciales) { //Bucle for-each que recorre cada elemento en la lista de naves
            System.out.println(n.toString()); //En cada iteración, llamo al metodo toString() de n
        }
    }
    
    public void iniciarExploracion() {
        for (NaveEspacial n : navesEspaciales) {
            if (n instanceof Explorable) { // Vetrifico si la nave n es una istancia de la interfaz Explorable
                ((Explorable) n).explorar();
            } else {
                System.out.println("La nave '" + n.nombre + "' es de tipo Crucero Estelar, y los cruceros no pueden ser explorados!!!!");
            }
        }
    }
    
}
