
package recuparcial1fiorelaquipildor;

public class Carguero extends NaveEspacial implements Explorable {
    private int capacidadCarga;

    public Carguero(int capacidadCarga, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void explorar() {
        System.out.println("Explorando la nave espacial '" + nombre +"'tipo Carguero.");
    }

    @Override
    public String toString() {
        return "Carguero{" + "capacidadCarga=" + capacidadCarga + ", nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + '}';
    }
    
}
