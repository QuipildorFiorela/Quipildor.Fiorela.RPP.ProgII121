
package recuparcial1fiorelaquipildor;

public enum TipoMision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO;
}
