
package recuparcial1fiorelaquipildor;

public class CruceroEstelar extends NaveEspacial {
    private int cantPasajeros;

    public CruceroEstelar(int cantPasajeros, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantPasajeros = cantPasajeros;
    }

    @Override
    public String toString() {
        return "CruceroEstelar{" + "cantPasajeros=" + cantPasajeros + ", nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + '}';
    }
    
}
