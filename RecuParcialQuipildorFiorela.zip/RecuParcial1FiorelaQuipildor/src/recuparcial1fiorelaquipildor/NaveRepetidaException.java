
package recuparcial1fiorelaquipildor;

public class NaveRepetidaException extends Exception {
    public  NaveRepetidaException(String mensaje) {
        super(mensaje);
    }
    public NaveRepetidaException(){
        super("mensaje");
    }
    
}
