
package recuparcial1fiorelaquipildor;

import java.util.ArrayList;
import java.util.List;

public class test {

    public static void main(String[] args) {
        
        List<NaveEspacial> listaNavesEspaciales = new ArrayList<>(); 
        
        Agencia agencia = new Agencia(listaNavesEspaciales);  
        
        NaveEspacial carguero1 = new Carguero(500, "Carguero Alfa", 10, 2020);
        NaveEspacial carguero2 = new Carguero(300, "Carguero OldLady", 50, 1950);
        NaveEspacial crucero1 = new CruceroEstelar(2500, "Crucero Estelar Titanic", 50, 1909);
        NaveEspacial crucero2 = new CruceroEstelar(5000, "Crucero Estelar Disney", 100, 2000);
        NaveEspacial exploracion1 = new Exploracion(TipoMision.CARTOGRAFIA, "Explorador Altlantico", 20, 2022);
        NaveEspacial exploracion2 = new Exploracion(TipoMision.INVESTIGACION, "Explorador Gamma", 15, 1998);

        try {
            agencia.agregarNave(carguero1);
            agencia.agregarNave(carguero2);
            agencia.agregarNave(crucero1);
            agencia.agregarNave(crucero2);
            agencia.agregarNave(exploracion1);
            agencia.agregarNave(exploracion2);

            
            agencia.agregarNave(carguero1);// Trato de agregar una nave duplicada para verificar la excepción
        } catch (NaveRepetidaException e) {
            System.out.println("Excepcion: " + e.getMessage());
        }

        // Mostrar todas las naves en la agencia
        System.out.println("--------- Lista de Naves en la Agencia ---------");
        agencia.mostrarNaves();

        // Iniciar exploración para las naves explorables
        System.out.println("--------------------------------------------------------------");
        System.out.println("-------- Iniciando Exploracion de Naves ---------");
        agencia.iniciarExploracion();
        
    }
    
}
