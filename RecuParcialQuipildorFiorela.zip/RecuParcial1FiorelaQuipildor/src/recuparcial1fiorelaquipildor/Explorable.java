
package recuparcial1fiorelaquipildor;

public interface Explorable {
    public void explorar();
}
