
package recuparcial1fiorelaquipildor;

import java.util.Objects;

public abstract class NaveEspacial {
    protected String nombre;
    protected int capacidadTripulacion;
    protected int anioLanzamiento;

    public NaveEspacial(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAnioLanzamiento() {
        return anioLanzamiento;
    }

    public void setAnioLanzamiento(int anioLanzamiento) {
        this.anioLanzamiento = anioLanzamiento;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.nombre);
        hash = 53 * hash + this.anioLanzamiento;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final NaveEspacial other = (NaveEspacial) obj;
        if (this.anioLanzamiento != other.anioLanzamiento) {
            return false;
        }
        return Objects.equals(this.nombre, other.nombre);
    }

    

    
    
    
}
